package gl.trial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInit1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringInit1Application.class, args);
	}
}
